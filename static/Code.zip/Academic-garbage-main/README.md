# 学术垃圾  
中北大学2024级C语言程序设计课程作业（赵山林版）  

## 第三章  
### Page 68  
#### 三、编程题  

1. 输出一个三位整数的逆序数。  
   解法1：[位分离法](https://github.com/X-MQSI/Academic-garbage/blob/main/P.68_3.1_1.c)  
   解法2：[逆序输出法](https://github.com/X-MQSI/Academic-garbage/blob/main/P.68_3.1_2.c)  

2. 计算球体的体积和表面积。  
   解法1：[常规解法](https://github.com/X-MQSI/Academic-garbage/blob/main/P.68_3.2_1.c)  
   ![image](https://github.com/user-attachments/assets/1e0b136c-d603-49c5-834c-13646020b055)  
   
3. 摄氏度转华氏度。  
   解法1. [常规解法](https://github.com/X-MQSI/Academic-garbage/blob/main/P.68_3.3_1.c)  
   ![image](https://github.com/user-attachments/assets/ba8a3e52-9575-4cef-a887-22f2a69f0785)  

## 其他内容
### 高等数学
1. 二分法求解函数近似根值
   源代码：[dichotomy.c](https://github.com/X-MQSI/Academic-garbage/blob/main/dichotomy.c)


**********
以上解法仅供参考。  
中北大学 航空宇航学院  
MQSI
